const fs = require('fs')

//settings bot
global.owner = "6288905301692"
global.nama = "Erlangga Developer"
global.reply = "https://files.catbox.moe/jq4f1s.jpg"
global.prefa = ["", "!", ".", ",", "🐤", "🗿"]; //not change!!
global.status = true
global.pairingcode = true //ubah ke false jika mau qr code


//mess
global.mess = {
    owner: "no, this is for owners only",
    group: "this is for groups only",
    private: "this is specifically for private chat",
    murbug: "for only user murbug.."
}

//nama seticker
global.packname = 'Sasuke Crash'
global.author = '\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\nMade Whit Erlangga Developer\nt.me/langgxyz2'

//End Settings

let file = require.resolve(__filename)
require('fs').watchFile(file, () => {
  require('fs').unwatchFile(file)
  console.log('\x1b[0;32m'+__filename+' \x1b[1;32mupdated!\x1b[0m')
  delete require.cache[file]
  require(file)
})
